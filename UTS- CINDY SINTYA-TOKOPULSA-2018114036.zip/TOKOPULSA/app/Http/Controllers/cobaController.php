<?php

namespace App\Http\Controllers;

use App\Models\forms;
use Illuminate\Http\Request;

class Cobacontroller extends Controller
{
    
    public function index()
    {
        
        $forms = Forms::orderBy('id', 'desc')->paginate(3);
        return view('forms.index', compact('forms'));
    }

    public function create()
    {
        
        return view('forms.create');
    }

    public function store (Request $request)
    {
        // validate the request...
        $request->validate([
            'Kartu_perdana' => 'required|unique:forms|max:255',
            'Harga_asli' =>'required|numeric',
            'Harga_jual' => 'required',
        ]);
        $forms = new Forms;
        
        $forms->Kartu_perdana = $request->Kartu_perdana;
        $forms->Harga_asli = $request->Harga_asli;
        $forms->Harga_jual = $request->Harga_jual ;

        $forms->save();

        return redirect('/');
    }
    public function show($id)
    {
        $forms= Forms::where('id', $id)->first();
        return view ('forms.show', ['form' => $forms]);
    }

    public function edit($id)
    {
        $forms= Forms::where('id', $id)->first();
        return view ('forms.edit', ['form' => $forms]);
    }
    public function update(Request $request, $id)
    {
        $request->validate([
            'Kartu_perdana' => 'required|unique:forms|max:255',
            'Harga_asli' =>'required|numeric',
            'Harga_jual' => 'required',
        ]);
        Forms::find($id)->update([
            'Kartu_perdana' => $request->Kartu_perdana,
            'Harga_asli' => $request->Harga_asli,
            'Harga_jual' => $request->Harga_jual,
        ]);

        return redirect ('/');
    }
    public function destroy($id)
    {
        Forms::find($id)->delete();
        return redirect ('/');
    }
}

