<?php

use App\Http\Controllers\cobaController;

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('', [cobaController::class, 'index']);
Route::get('/forms', [cobaController::class, 'index']);
Route::get('/forms/create', [cobaController::class, 'create']);
Route::post('/forms', [cobaController::class, 'store']);
Route::get('/forms/{id}', [cobaController::class, 'show']);
Route::get('/forms/{id}/edit', [cobaController::class, 'edit']);
Route::put('/forms/{id}', [cobaController::class, 'update']);
Route::delete('/forms/{id}', [cobaController::class, 'destroy']);
