

<?php $__env->startSection('title', 'Forms'); ?>

<?php $__env->startSection('content'); ?>

<?php $__currentLoopData = $forms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $form): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="card" style="width: 18rem;">
  <div class="card-body">
    <h5 class="card-title"> <?php echo e($form['Kartu_perdana']); ?></h5>
    <h6 class="card-subtitle mb-2 text-muted"><?php echo e($form['Harga_asli']); ?></h6>
    <p class="card-text"><?php echo e($form['Harga_jual']); ?></p>
    <a href="#" class="card-link btn-primary">Tambah saldo</a>
    <a href="#" class="card-link btn-warning">Edit saldo</a>
    <a href="#" class="card-link btn-danger">Delete saldo</a>
  </div>
</div>


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<div>
    <?php echo e($forms->links()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TOKOPULSA\resources\views/index.blade.php ENDPATH**/ ?>