<?php $__env->startSection('title', 'cobaaaaa'); ?>

<?php $__env->startSection('content'); ?>
    <h3>Kartu perdana : <?php echo e($form['Kartu_perdana']); ?></h3>
    <h3>Harga asli : <?php echo e($form['Harga_asli']); ?></h3>
    <h3>Harga jual : <?php echo e($form['Harga_jual']); ?></h3>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TOKOPULSA\resources\views/forms/show.blade.php ENDPATH**/ ?>