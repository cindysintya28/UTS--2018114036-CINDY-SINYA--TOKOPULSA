

<?php $__env->startSection('title', 'forms'); ?>

<?php $__env->startSection('content'); ?>

<?php $__currentLoopData = $forms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $form): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="card" style="width: 18rem;">
  <div class="card-body">
    <a href="/forms/<?php echo e($form['Id']); ?>" class="card-title"> <?php echo e($form['Kartu_perdana']); ?></a>
    <h6 class="card-subtitle mb-2 text-muted"><?php echo e($form['Harga_asli']); ?></h6>
    <p class="card-text"><?php echo e($form['Harga_jual']); ?></p>

  <a href="/forms/<?php echo e($form['id']); ?>/Edit" class="card-link btn-warning">Edit saldo</a>
<form action="/forms/<?php echo e($form['id']); ?>" method="POST">
<?php echo csrf_field(); ?>
<?php echo method_field('DELETE'); ?>
    <button class="card-link btn-danger">Delete saldo </a>
 </form>
  </div>
</div>


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<div>
    <?php echo e($forms->links()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TOKOPULSA\resources\views/forms/index.blade.php ENDPATH**/ ?>