

<?php $__env->startSection('title', 'Forms'); ?>

<?php $__env->startSection('content'); ?>


<form action="/forms" method="post">
  <?php echo csrf_field(); ?>
  <div class="form-group">
    <label for="exampleInputEmail1">Kartu_perdana</label>
    <input type="text" class="form-control" id="exampleInputEmail1"  name="Kartu_perdana" aria-describedby="emailHelp">
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Harga_asli</label>
    <input type="text" class="form-control" name="Harga_asli" id="exampleInputPassword1">
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Harga_jual</label>
    <input type="text" class="form-control" name="Harga_jual" id="exampleInputPassword1">
  </div>
  
  <button type="submit" class="btn btn-primary">Submit</button>
</form>
   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TOKOPULSA\resources\views/create.blade.php ENDPATH**/ ?>