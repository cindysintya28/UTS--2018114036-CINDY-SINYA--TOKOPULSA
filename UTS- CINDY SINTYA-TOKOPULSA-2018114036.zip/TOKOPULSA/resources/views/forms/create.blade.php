@extends('layouts.app')

@section('title', 'Forms')

@section('content')


<form action="/forms" method="post">
  @csrf
  <div class="form-group">
    <label for="exampleInputEmail1">Kartu_perdana</label>
    <input type="text" class="form-control" id="exampleInputEmail1"  name="Kartu_perdana" aria-describedby="emailHelp" value="{{old('Kartu_perdana')}}">
    @error('Kartu_perdana')
    <div class="alert alert-danger">{{ $message }}</div>
  @enderror
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Harga_asli</label>
    <input type="text" class="form-control" name="Harga_asli" id="exampleInputPassword1" value="{{old('Harga_asli')}}">
    @error('Harga_asli')
    <div class="alert alert-danger">{{ $message }}</div>
  @enderror
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Harga_jual</label>
    <input type="text" class="form-control" name="Harga_jual" id="exampleInputPassword1"value="{{old('Harga_jual')}}">
    @error('Harga_jual')
    <div class="alert alert-danger">{{ $message }}</div>
  @enderror
  </div>
  
  <button type="submit" class="btn btn-primary">Submit</button>
</form>
   
@endsection