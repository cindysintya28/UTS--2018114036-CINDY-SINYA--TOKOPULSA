@extends('layouts.app')

@section('title', 'forms')

@section('content')

@foreach($forms as $form)

<div class="card" style="width: 18rem;">
  <div class="card-body">
    <a href="/forms/{{$form['Id']}}" class="card-title"> {{$form['Kartu_perdana']}}</a>
    <h6 class="card-subtitle mb-2 text-muted">{{$form['Harga_asli']}}</h6>
    <p class="card-text">{{$form['Harga_jual']}}</p>

  <a href="/forms/{{$form['id']}}/Edit" class="card-link btn-warning">Edit saldo</a>
<form action="/forms/{{$form['id']}}" method="POST">
@csrf
@method ('DELETE')
    <button class="card-link btn-danger">Delete saldo </a>
 </form>
  </div>
</div>


@endforeach
<div>
    {{$forms->links()}}
</div>
@endsection