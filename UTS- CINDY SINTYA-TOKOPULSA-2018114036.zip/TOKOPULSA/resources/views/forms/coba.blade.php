@extends('layouts.app')

@section('title', 'cobaaaaa')

@section ('content')
    urutan ke - {{$ke}}
@endsection