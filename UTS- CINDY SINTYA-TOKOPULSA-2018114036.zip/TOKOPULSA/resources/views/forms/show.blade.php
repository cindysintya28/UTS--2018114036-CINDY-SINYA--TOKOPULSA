@extends('layouts.app')

@section('title', 'cobaaaaa')

@section ('content')
    <h3>Kartu perdana : {{ $form['Kartu_perdana'] }}</h3>
    <h3>Harga asli : {{ $form['Harga_asli'] }}</h3>
    <h3>Harga jual : {{ $form['Harga_jual'] }}</h3>
@endsection